Contem os arquivos do trabalho de Estrutura de Dados 1 (Universidade Federal de Uberlândia) sobre Listas usando Tipos Abstratos de Dados.

Entre as resoluções há problemas envolvendos listas estáticas não ordenadas, listas dinamicas ordenadas, lista dinamica com nó-cabeçalho, e por fim, listas simples e duplamente circulares.
